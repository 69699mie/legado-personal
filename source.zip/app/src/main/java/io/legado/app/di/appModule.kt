package io.legado.app.di

import android.os.Build
import coil3.ImageLoader
import coil3.gif.AnimatedImageDecoder
import coil3.gif.GifDecoder
import coil3.request.crossfade
import coil3.svg.SvgDecoder
import io.legado.app.data.AppDatabase
import io.legado.app.data.repository.AiArtifactRepository
import io.legado.app.data.repository.AiChatRepository
import io.legado.app.data.repository.AiMemoryRepository
import io.legado.app.data.repository.AiProfileRepository
import io.legado.app.data.repository.AiPromptPresetRepository
import io.legado.app.data.repository.AiTextRepositoryImpl
import io.legado.app.data.repository.AiToolRepository
import io.legado.app.data.repository.AppLocaleRepository
import io.legado.app.data.repository.AppShellSettingsRepository
import io.legado.app.data.repository.AppStartupRepository
import io.legado.app.data.repository.AppUiConfigurationRepository
import io.legado.app.data.repository.BackupRestoreRepository
import io.legado.app.data.repository.BackupSettingsRepository
import io.legado.app.data.repository.BookCacheCleanupRepository
import io.legado.app.data.repository.BookCacheManageRepository
import io.legado.app.data.repository.BookContentProcessRepository
import io.legado.app.data.repository.BookDomainRepositoryImpl
import io.legado.app.data.repository.BookExportSettingsRepository
import io.legado.app.data.repository.BookGroupMutationRepository
import io.legado.app.data.repository.BookGroupRepository
import io.legado.app.data.repository.BookImportRepository
import io.legado.app.data.repository.BookKnowledgeRepository
import io.legado.app.data.repository.BookMarkingRepository
import io.legado.app.data.repository.BookRepository
import io.legado.app.data.repository.BookSourceCallbackRepository
import io.legado.app.data.repository.BookSourceCheckRepository
import io.legado.app.data.repository.BookSourceRepository
import io.legado.app.data.repository.BookmarkRepository
import io.legado.app.data.repository.BookshelfAutoGroupPromptRepository
import io.legado.app.data.repository.BookshelfAutoGroupRepository
import io.legado.app.data.repository.BookshelfRepository
import io.legado.app.data.repository.BookshelfSettingsRepository
import io.legado.app.data.repository.CacheBookDownloadRepository
import io.legado.app.data.repository.ChangeSourceSettingsRepository
import io.legado.app.data.repository.ChapterSpeechRepository
import io.legado.app.data.repository.CheckSourceSettingsRepository
import io.legado.app.data.repository.CloudTtsEngineRepository
import io.legado.app.data.repository.CoverAlbumRepository
import io.legado.app.data.repository.CoverSettingsRepository
import io.legado.app.data.repository.DatabaseMaintenanceRepository
import io.legado.app.data.repository.DictRuleRepository
import io.legado.app.data.repository.DictionaryRepositoryImpl
import io.legado.app.data.repository.DirectLinkSettingsRepository
import io.legado.app.data.repository.DirectLinkUploadRepository
import io.legado.app.data.repository.DownloadCacheSettingsRepository
import io.legado.app.data.repository.ExploreRepository
import io.legado.app.data.repository.ExploreRepositoryImpl
import io.legado.app.data.repository.HighlightRuleRepository
import io.legado.app.data.repository.HighlightTagRuleRepository
import io.legado.app.data.repository.HomeDashboardRepository
import io.legado.app.data.repository.HomepageModulesRepository
import io.legado.app.data.repository.HomepageSettingsRepository
import io.legado.app.data.repository.HttpTtsEngineRepository
import io.legado.app.data.repository.HttpTtsRepository
import io.legado.app.data.repository.ImportBookSettingsRepository
import io.legado.app.data.repository.LabSettingsRepository
import io.legado.app.data.repository.LocalBookRepository
import io.legado.app.data.repository.LocalPasswordRepository
import io.legado.app.data.repository.MangaSettingsRepository
import io.legado.app.data.repository.OtherConfigSystemRepository
import io.legado.app.data.repository.OtherSettingsRepository
import io.legado.app.data.repository.PrivateAccessRepository
import io.legado.app.data.repository.PrivateContentRepository
import io.legado.app.data.repository.ReadAloudSettingsRepository
import io.legado.app.data.repository.ReadAloudVoiceRepository
import io.legado.app.data.repository.ReadBookStyleConfigRepository
import io.legado.app.data.repository.ReadRecordRepository
import io.legado.app.data.repository.ReadSettingsRepository
import io.legado.app.data.repository.ReadStyleConfigStore
import io.legado.app.data.repository.ReadStyleRepository
import io.legado.app.data.repository.RemoteBookRepository
import io.legado.app.data.repository.ReplaceRuleRepository
import io.legado.app.data.repository.RssArticleRepository
import io.legado.app.data.repository.RssFavoriteRepository
import io.legado.app.data.repository.RssReadRecordRepository
import io.legado.app.data.repository.RssRepository
import io.legado.app.data.repository.RssSourceEditRepository
import io.legado.app.data.repository.RuleSubscriptionRepository
import io.legado.app.data.repository.SearchContentRepository
import io.legado.app.data.repository.SearchRepository
import io.legado.app.data.repository.SearchRepositoryImpl
import io.legado.app.data.repository.SettingsRepository
import io.legado.app.data.repository.TagGroupRuleApplier
import io.legado.app.data.repository.ThemePackageSettingsRepository
import io.legado.app.data.repository.ThemeSettingsRepository
import io.legado.app.data.repository.TranslationCacheRepositoryImpl
import io.legado.app.data.repository.TranslationSettingsRepository
import io.legado.app.data.repository.TxtTocRuleRepository
import io.legado.app.data.repository.UploadRepository
import io.legado.app.data.repository.WebDavBackupRepository
import io.legado.app.data.repository.WebDavReadingProgressRepository
import io.legado.app.data.repository.manga.DefaultMangaReaderSession
import io.legado.app.data.repository.manga.MangaReaderActionRepository
import io.legado.app.data.repository.manga.MangaReaderDataRepository
import io.legado.app.data.security.CloudTtsCredentialCipher
import io.legado.app.domain.gateway.AiArtifactGateway
import io.legado.app.domain.gateway.AiChatGateway
import io.legado.app.domain.gateway.AiMemoryGateway
import io.legado.app.domain.gateway.AiProfileGateway
import io.legado.app.domain.gateway.AiPromptPresetGateway
import io.legado.app.domain.gateway.AiTextGateway
import io.legado.app.domain.gateway.AiToolGateway
import io.legado.app.domain.gateway.AppLocaleGateway
import io.legado.app.domain.gateway.AppShellSettingsGateway
import io.legado.app.domain.gateway.AppStartupGateway
import io.legado.app.domain.gateway.AppUiConfigurationGateway
import io.legado.app.domain.gateway.BackupRestoreGateway
import io.legado.app.domain.gateway.BackupSettingsGateway
import io.legado.app.domain.gateway.BookCacheCleanupGateway
import io.legado.app.domain.gateway.BookCacheDownloadGateway
import io.legado.app.domain.gateway.BookContentProcessGateway
import io.legado.app.domain.gateway.BookExportSettingsGateway
import io.legado.app.domain.gateway.BookGroupMutationGateway
import io.legado.app.domain.gateway.BookKnowledgeGateway
import io.legado.app.domain.gateway.BookMarkingGateway
import io.legado.app.domain.gateway.BookSearchGateway
import io.legado.app.domain.gateway.BookSourceCallbackGateway
import io.legado.app.domain.gateway.BookSourceCheckGateway
import io.legado.app.domain.gateway.BookshelfAutoGroupGateway
import io.legado.app.domain.gateway.BookshelfAutoGroupPromptGateway
import io.legado.app.domain.gateway.BookshelfSettingsGateway
import io.legado.app.domain.gateway.ChangeSourceSettingsGateway
import io.legado.app.domain.gateway.ChapterSpeechGateway
import io.legado.app.domain.gateway.CheckSourceSettingsGateway
import io.legado.app.domain.gateway.CloudTtsEngineGateway
import io.legado.app.domain.gateway.CoverAlbumGateway
import io.legado.app.domain.gateway.CoverSettingsGateway
import io.legado.app.domain.gateway.DatabaseMaintenanceGateway
import io.legado.app.domain.gateway.DictionaryGateway
import io.legado.app.domain.gateway.DirectLinkSettingsGateway
import io.legado.app.domain.gateway.DownloadCacheSettingsGateway
import io.legado.app.domain.gateway.ExploreBooksGateway
import io.legado.app.domain.gateway.HomeDashboardGateway
import io.legado.app.domain.gateway.HomepageModulesGateway
import io.legado.app.domain.gateway.HomepageSettingsGateway
import io.legado.app.domain.gateway.HttpTtsEngineGateway
import io.legado.app.domain.gateway.ImportBookSettingsGateway
import io.legado.app.domain.gateway.LabSettingsGateway
import io.legado.app.domain.gateway.LocalBookGateway
import io.legado.app.domain.gateway.LocalPasswordGateway
import io.legado.app.domain.gateway.MangaReaderDataGateway
import io.legado.app.domain.gateway.MangaReaderSessionFactory
import io.legado.app.domain.gateway.MangaSettingsGateway
import io.legado.app.domain.gateway.OtherConfigSystemGateway
import io.legado.app.domain.gateway.OtherSettingsGateway
import io.legado.app.domain.gateway.PlaybackCapsuleGateway
import io.legado.app.domain.gateway.PrivateAccessGateway
import io.legado.app.domain.gateway.PrivateContentGateway
import io.legado.app.domain.gateway.ReadAloudSettingsGateway
import io.legado.app.domain.gateway.ReadAloudVoiceGateway
import io.legado.app.domain.gateway.ReadSettingsGateway
import io.legado.app.domain.gateway.ReadStyleGateway
import io.legado.app.domain.gateway.ReadingProgressGateway
import io.legado.app.domain.gateway.ThemePackageSettingsGateway
import io.legado.app.domain.gateway.ThemeSettingsGateway
import io.legado.app.domain.gateway.TranslationCacheGateway
import io.legado.app.domain.gateway.TranslationSettingsGateway
import io.legado.app.domain.gateway.WebDavBackupGateway
import io.legado.app.domain.repository.BookDomainRepository
import io.legado.app.domain.usecase.AddBookUseCase
import io.legado.app.domain.usecase.AddToBookshelfUseCase
import io.legado.app.domain.usecase.AiChatGenerationUseCase
import io.legado.app.domain.usecase.AiTaskManager
import io.legado.app.domain.usecase.AiTextFactoryUseCase
import io.legado.app.domain.usecase.AiToolAwareGenerationUseCase
import io.legado.app.domain.usecase.AnalyzeChapterSpeechUseCase
import io.legado.app.domain.usecase.AppStartupMaintenanceUseCase
import io.legado.app.domain.usecase.ApplyBookshelfAutoGroupPlanUseCase
import io.legado.app.domain.usecase.BackupRestoreUseCase
import io.legado.app.domain.usecase.BatchCacheDownloadUseCase
import io.legado.app.domain.usecase.BuildSpeechPlanUseCase
import io.legado.app.domain.usecase.CacheBookChaptersUseCase
import io.legado.app.domain.usecase.ChangeBookSourceUseCase
import io.legado.app.domain.usecase.ChangeSourceSearchUseCase
import io.legado.app.domain.usecase.CheckBookContentQualityUseCase
import io.legado.app.domain.usecase.CleanSelectedTextUseCase
import io.legado.app.domain.usecase.ClearBookCacheUseCase
import io.legado.app.domain.usecase.CoverAlbumUseCase
import io.legado.app.domain.usecase.DeleteBooksUseCase
import io.legado.app.domain.usecase.ExploreBooksUseCase
import io.legado.app.domain.usecase.ExploreKindUiUseCase
import io.legado.app.domain.usecase.ExportBookshelfUseCase
import io.legado.app.domain.usecase.FindBookshelfConflictUseCase
import io.legado.app.domain.usecase.GenerateBookshelfAutoGroupPlanUseCase
import io.legado.app.domain.usecase.GenerateChapterSummaryUseCase
import io.legado.app.domain.usecase.GetChapterContentUseCase
import io.legado.app.domain.usecase.GetReadingProgressUseCase
import io.legado.app.domain.usecase.HomeDashboardUseCase
import io.legado.app.domain.usecase.IdentifyBookCharactersUseCase
import io.legado.app.domain.usecase.ImportBookshelfUseCase
import io.legado.app.domain.usecase.PrepareChapterSpeechPlanUseCase
import io.legado.app.domain.usecase.RefineSpeechWithAiUseCase
import io.legado.app.domain.usecase.RefreshTocUseCase
import io.legado.app.domain.usecase.RelocateMarkingTargetUseCase
import io.legado.app.domain.usecase.RemoveBookGroupAssignmentUseCase
import io.legado.app.domain.usecase.ResolveBookShelfStateUseCase
import io.legado.app.domain.usecase.ResolveBookshelfConflictUseCase
import io.legado.app.domain.usecase.ResolveLocalSpeakersUseCase
import io.legado.app.domain.usecase.SaveBookContentProcessUseCase
import io.legado.app.domain.usecase.SaveMarkingUseCase
import io.legado.app.domain.usecase.SaveSearchBooksUseCase
import io.legado.app.domain.usecase.SearchBooksUseCase
import io.legado.app.domain.usecase.ShrinkDatabaseUseCase
import io.legado.app.domain.usecase.StartBookSourceCheckUseCase
import io.legado.app.domain.usecase.SyncReadAloudVoicesUseCase
import io.legado.app.domain.usecase.TranslateChapterUseCase
import io.legado.app.domain.usecase.UpdateBooksGroupUseCase
import io.legado.app.domain.usecase.UploadReadingProgressUseCase
import io.legado.app.domain.usecase.VerifyBookmarkTargetUseCase
import io.legado.app.domain.usecase.WebDavBackupUseCase
import io.legado.app.domain.usecase.readRecord.GetReadRecordOverviewUseCase
import io.legado.app.feature.explore.ExploreMainViewModel
import io.legado.app.feature.onboarding.OnboardingViewModel
import io.legado.app.help.coil.CoverFetcher
import io.legado.app.help.coil.CoverInterceptor
import io.legado.app.help.config.ThemePackageManager
import io.legado.app.help.http.okHttpClient
import io.legado.app.help.http.okHttpClientManga
import io.legado.app.model.LegacyReaderSession
import io.legado.app.model.ReadAloudSessionStore
import io.legado.app.model.ReaderSession
import io.legado.app.service.playback.PlaybackCapsuleGatewayAdapter
import io.legado.app.ui.about.AboutViewModel
import io.legado.app.ui.ai.chat.AiChatViewModel
import io.legado.app.ui.association.ImportDictRuleViewModel
import io.legado.app.ui.association.ImportHttpTtsViewModel
import io.legado.app.ui.association.ImportReplaceRuleViewModel
import io.legado.app.ui.association.ImportRssSourceViewModel
import io.legado.app.ui.association.ImportTxtTocRuleViewModel
import io.legado.app.ui.book.audio.AudioPlayCoordinator
import io.legado.app.ui.book.audio.AudioPlayViewModel
import io.legado.app.ui.book.bookmark.AllBookmarkViewModel
import io.legado.app.ui.book.cache.manage.BookCacheManageViewModel
import io.legado.app.ui.book.changecover.ChangeCoverViewModel
import io.legado.app.ui.book.changesource.ChangeBookSourceComposeViewModel
import io.legado.app.ui.book.changesource.ChangeChapterSourceViewModel
import io.legado.app.ui.book.explore.ExploreShowViewModel
import io.legado.app.ui.book.group.GroupViewModel
import io.legado.app.ui.book.import.local.ImportBookViewModel
import io.legado.app.ui.book.import.remote.RemoteBookViewModel
import io.legado.app.ui.book.import.remote.ServerConfigViewModel
import io.legado.app.ui.book.import.remote.ServersViewModel
import io.legado.app.ui.book.info.BookInfoViewModel
import io.legado.app.ui.book.info.edit.BookInfoEditViewModel
import io.legado.app.ui.book.knowledge.BookCharacterDetailViewModel
import io.legado.app.ui.book.knowledge.BookCharacterListViewModel
import io.legado.app.ui.book.knowledge.BookCharacterNetworkViewModel
import io.legado.app.ui.book.knowledge.BookEventDetailViewModel
import io.legado.app.ui.book.knowledge.BookEventListViewModel
import io.legado.app.ui.book.knowledge.BookKnowledgeDetailViewModel
import io.legado.app.ui.book.knowledge.BookKnowledgeListViewModel
import io.legado.app.ui.book.manage.BookshelfManageScreenViewModel
import io.legado.app.ui.book.manga.MangaReaderViewModel
import io.legado.app.ui.book.read.ReadBookViewModel
import io.legado.app.ui.book.read.ReaderSessionViewModel
import io.legado.app.ui.book.readRecord.ReadRecordOverviewViewModel
import io.legado.app.ui.book.readRecord.ReadRecordViewModel
import io.legado.app.ui.book.readaloud.cache.TtsCacheViewModel
import io.legado.app.ui.book.readaloud.casting.BookVoiceCastingViewModel
import io.legado.app.ui.book.readaloud.cloudtts.CloudTtsViewModel
import io.legado.app.ui.book.readaloud.player.ReadAloudPlayerCoordinator
import io.legado.app.ui.book.readaloud.player.ReadAloudPlayerViewModel
import io.legado.app.ui.book.search.SearchViewModel
import io.legado.app.ui.book.searchContent.SearchContentViewModel
import io.legado.app.ui.book.source.debug.BookSourceDebugViewModel
import io.legado.app.ui.book.source.edit.BookSourceEditViewModel
import io.legado.app.ui.book.source.manage.BookSourceViewModel
import io.legado.app.ui.book.toc.TocViewModel
import io.legado.app.ui.book.toc.rule.TxtTocRuleViewModel
import io.legado.app.ui.book.toc.rule.preview.TxtTocRulePreviewViewModel
import io.legado.app.ui.browser.WebViewModel
import io.legado.app.ui.config.ai.AiConfigViewModel
import io.legado.app.ui.config.ai.AiModelEditViewModel
import io.legado.app.ui.config.ai.AiProviderEditViewModel
import io.legado.app.ui.config.ai.prompt.AiPromptConfigViewModel
import io.legado.app.ui.config.ai.summary.AiSummaryConfigViewModel
import io.legado.app.ui.config.backupConfig.BackupConfigViewModel
import io.legado.app.ui.config.bookshelfConfig.BookshelfManageScreenConfig
import io.legado.app.ui.config.coverConfig.CoverAlbumManageViewModel
import io.legado.app.ui.config.coverConfig.CoverConfigViewModel
import io.legado.app.ui.config.customTheme.CustomThemeViewModel
import io.legado.app.ui.config.downloadCacheConfig.DownloadCacheConfigViewModel
import io.legado.app.ui.config.labConfig.LabConfigViewModel
import io.legado.app.ui.config.otherConfig.OtherConfigViewModel
import io.legado.app.ui.config.privateConfig.PrivateConfigViewModel
import io.legado.app.ui.config.readConfig.ApplyReadSettingUseCase
import io.legado.app.ui.config.readConfig.ReadConfigViewModel
import io.legado.app.ui.config.themeConfig.ThemeConfigViewModel
import io.legado.app.ui.config.themeManage.ThemeManageViewModel
import io.legado.app.ui.config.translation.TranslationConfigViewModel
import io.legado.app.ui.dict.DictViewModel
import io.legado.app.ui.dict.rule.DictRuleViewModel
import io.legado.app.help.readaloud.cast.AiCastAssignUseCase
import io.legado.app.help.readaloud.cast.AiSceneAssignUseCase
import io.legado.app.ui.book.readaloud.cast.VoiceEffectViewModel
import io.legado.app.ui.book.readaloud.cast.BgmPoolViewModel
import io.legado.app.ui.book.readaloud.cast.RegexCastRuleViewModel
import io.legado.app.ui.book.readaloud.cast.MultiRoleRuleViewModel
import io.legado.app.ui.book.readaloud.cast.MultiRoleRecognitionViewModel
import io.legado.app.ui.highlightTagRule.HighlightTagRuleViewModel
import io.legado.app.ui.login.SourceLoginViewModel
import io.legado.app.ui.main.MainNavRouteTracker
import io.legado.app.ui.main.MainRouteSearchContent
import io.legado.app.ui.main.MainViewModel
import io.legado.app.ui.main.bookshelf.BookshelfCoverPreloader
import io.legado.app.ui.main.bookshelf.BookshelfViewModel
import io.legado.app.ui.main.bookshelf.autoGroup.AiAutoGroupViewModel
import io.legado.app.ui.main.explore.ExploreViewModel
import io.legado.app.ui.main.home.HomeViewModel
import io.legado.app.ui.main.homepage.HomepageViewModel
import io.legado.app.ui.main.my.MyViewModel
import io.legado.app.ui.main.rss.RssViewModel
import io.legado.app.ui.replace.ReplaceEditRoute
import io.legado.app.ui.replace.ReplaceRuleViewModel
import io.legado.app.ui.replace.edit.ReplaceEditViewModel
import io.legado.app.ui.rss.article.RssArticlesViewModel
import io.legado.app.ui.rss.article.RssSortViewModel
import io.legado.app.ui.rss.favorites.RssFavoritesViewModel
import io.legado.app.ui.rss.read.ReadRssViewModel
import io.legado.app.ui.rss.source.debug.RssSourceDebugViewModel
import io.legado.app.ui.rss.source.edit.RssSourceEditViewModel
import io.legado.app.ui.rss.source.manage.RssSourceViewModel
import io.legado.app.ui.rss.subscription.RuleSubViewModel
import io.legado.app.ui.tagGroupRule.TagGroupRuleViewModel
import io.legado.app.ui.widget.components.privacy.PrivateReadGateViewModel
import io.legado.app.utils.isNightMode
import io.legado.app.utils.sysConfiguration
import kotlinx.coroutines.Dispatchers
import org.koin.core.module.dsl.factoryOf
import org.koin.core.module.dsl.singleOf
import org.koin.core.module.dsl.viewModel
import org.koin.core.module.dsl.viewModelOf
import org.koin.dsl.module
import kotlin.time.Clock

val appModule = module {

    single { get<AppDatabase>().readRecordDao }
    single { get<AppDatabase>().bookDao }
    single { get<AppDatabase>().bookChapterDao }
    single { get<AppDatabase>().bookGroupDao }
    single { get<AppDatabase>().bookSourceDao }
    single { get<AppDatabase>().searchContentHistoryDao }
    single { get<AppDatabase>().rssStarDao }
    single { get<AppDatabase>().ruleSubDao }

    singleOf(::ReadRecordRepository)
    single<HomeDashboardGateway> { HomeDashboardRepository(get(), get()) }
    singleOf(::BookRepository)
    singleOf(::BookImportRepository)
    singleOf(::BookGroupRepository)
    singleOf(::BookmarkRepository)
    singleOf(::BookCacheManageRepository)
    singleOf(::TagGroupRuleApplier)
    single<BookGroupMutationGateway> { BookGroupMutationRepository(get(), get()) }
    single<BookshelfAutoGroupGateway> { BookshelfAutoGroupRepository(get()) }
    single<BookshelfAutoGroupPromptGateway> { BookshelfAutoGroupPromptRepository(get()) }
    singleOf(::BookSourceRepository)
    singleOf(::BookshelfRepository)
    singleOf(::DictRuleRepository)
    singleOf(::TxtTocRuleRepository)
    single {
        SearchContentRepository(
            titleModeProvider = { io.legado.app.help.config.ReadBookConfig.titleMode },
            historyDao = get(),
            readSettingsGateway = get(),
            otherSettingsGateway = get(),
        )
    }
    singleOf(::RemoteBookRepository)
    singleOf(::SettingsRepository)
    single<AppLocaleGateway> { AppLocaleRepository() }
    single<AppShellSettingsGateway> { AppShellSettingsRepository() }
    single<ThemeSettingsGateway> { ThemeSettingsRepository() }
    single<ThemePackageSettingsGateway> { ThemePackageSettingsRepository() }
    single<AppUiConfigurationGateway> {
        AppUiConfigurationRepository(
            appLocaleGateway = get(),
            initialSystemDarkTheme = sysConfiguration.isNightMode,
        )
    }
    single<OtherSettingsGateway> { OtherSettingsRepository() }
    single<CheckSourceSettingsGateway> { CheckSourceSettingsRepository() }
    single { BookSourceCheckRepository(get(), get(), get()) }
    single<BookSourceCheckGateway> { get<BookSourceCheckRepository>() }
    singleOf(::StartBookSourceCheckUseCase)
    single<DirectLinkSettingsGateway> { DirectLinkSettingsRepository() }
    single<LocalPasswordGateway> { LocalPasswordRepository() }
    // 私密内容：解锁凭据与书籍标记分开绑定，接口归属保持显式
    single<PrivateAccessGateway> { PrivateAccessRepository(get(), get()) }
    single<PrivateContentGateway> { PrivateContentRepository(get()) }
    single<OtherConfigSystemGateway> { OtherConfigSystemRepository(get()) }
    single<DownloadCacheSettingsGateway> { DownloadCacheSettingsRepository() }
    single<CoverSettingsGateway> { CoverSettingsRepository() }
    single<BackupSettingsGateway> { BackupSettingsRepository() }
    single<LabSettingsGateway> { LabSettingsRepository() }
    single<MangaSettingsGateway> { MangaSettingsRepository() }
    single<ChangeSourceSettingsGateway> { ChangeSourceSettingsRepository() }
    single<ImportBookSettingsGateway> { ImportBookSettingsRepository() }
    single<TranslationSettingsGateway> { TranslationSettingsRepository() }
    single<BookshelfSettingsGateway> { BookshelfSettingsRepository() }
    single { ReadSettingsRepository(settingsRepository = get()) }
    single<ReadSettingsGateway> { get<ReadSettingsRepository>() }
    singleOf(::ReadAloudSettingsRepository)
    singleOf(::ReadAloudSessionStore)
    single<PlaybackCapsuleGateway> { PlaybackCapsuleGatewayAdapter(get(), get()) }
    singleOf(::MainNavRouteTracker)
    // 会话每个所有者一份。ReadBook.callBack 的身份是「阅读页已挂载」信号
    // （prefetchForOpen / upData 判 callBack != null），register 还会给上一个持有者
    // 发 notifyBookChanged——单例会把两个 ReadBookViewModel 的注册身份混成一个。
    factory<ReaderSession> { LegacyReaderSession() }
    single<HttpTtsEngineGateway> { HttpTtsEngineRepository(get()) }
    single<ReadAloudSettingsGateway> { get<ReadAloudSettingsRepository>() }
    singleOf(::HttpTtsRepository)
    singleOf(::ApplyReadSettingUseCase)
    singleOf(::HighlightRuleRepository)
    singleOf(::HighlightTagRuleRepository)
    singleOf(::ReadStyleRepository)
    singleOf(::ReadStyleConfigStore)
    singleOf(::ReadBookStyleConfigRepository)
    single<ReadStyleGateway> { get<ReadBookStyleConfigRepository>() }
    factoryOf(::MangaReaderDataRepository)
    factoryOf(::MangaReaderActionRepository)
    factory<MangaReaderDataGateway> { get<MangaReaderDataRepository>() }
    factory<MangaReaderSessionFactory> {
        MangaReaderSessionFactory {
            DefaultMangaReaderSession(
                dataGateway = get<MangaReaderDataGateway>(),
                stateDispatcher = Dispatchers.Default,
                ioDispatcher = Dispatchers.IO,
            )
        }
    }
    singleOf(::ExploreBooksUseCase)
    singleOf(::ExploreKindUiUseCase)
    singleOf(::SaveSearchBooksUseCase)
    singleOf(::AppStartupMaintenanceUseCase)
    singleOf(::BackupRestoreUseCase)
    singleOf(::BatchCacheDownloadUseCase)
    singleOf(::BuildSpeechPlanUseCase)
    singleOf(::AnalyzeChapterSpeechUseCase)
    singleOf(::ResolveLocalSpeakersUseCase)
    singleOf(::PrepareChapterSpeechPlanUseCase)
    singleOf(::RefineSpeechWithAiUseCase)
    singleOf(::SyncReadAloudVoicesUseCase)
    singleOf(::CacheBookChaptersUseCase)
    singleOf(::ChangeBookSourceUseCase)
    singleOf(::ClearBookCacheUseCase)
    singleOf(::CoverAlbumUseCase)
    singleOf(::DeleteBooksUseCase)
    singleOf(::GetReadingProgressUseCase)
    single { HomeDashboardUseCase(get(), Clock.System) }
    singleOf(::RemoveBookGroupAssignmentUseCase)
    singleOf(::UpdateBooksGroupUseCase)
    singleOf(::UploadReadingProgressUseCase)
    singleOf(::ResolveBookShelfStateUseCase)
    singleOf(::RefreshTocUseCase)
    singleOf(::AddBookUseCase)
    singleOf(::AddToBookshelfUseCase)
    singleOf(::FindBookshelfConflictUseCase)
    singleOf(::ResolveBookshelfConflictUseCase)
    singleOf(::ImportBookshelfUseCase)
    singleOf(::ExportBookshelfUseCase)
    factory { GetReadRecordOverviewUseCase() }
    singleOf(::ShrinkDatabaseUseCase)
    singleOf(::WebDavBackupUseCase)
    singleOf(::BookshelfManageScreenConfig)
    singleOf(::ThemePackageManager)

    single<UploadRepository> { DirectLinkUploadRepository() }
    single<TranslationCacheGateway> { TranslationCacheRepositoryImpl() }
    single<AiProfileGateway> { AiProfileRepository(get()) }
    single<AiArtifactGateway> { AiArtifactRepository(get()) }
    single<AiChatGateway> { AiChatRepository(get()) }
    single<AiMemoryGateway> { AiMemoryRepository(get()) }
    single<AiPromptPresetGateway> { AiPromptPresetRepository(get()) }
    single<AiTextGateway> { AiTextRepositoryImpl() }
    single<AiToolGateway> {
        AiToolRepository(
            get(),
            get(),
            get(),
            get(),
            get(),
            get(),
            get(),
            get()
        )
    }
    single<AppStartupGateway> { AppStartupRepository(get()) }
    single<BackupRestoreGateway> { BackupRestoreRepository() }
    single<BookCacheDownloadGateway> { CacheBookDownloadRepository(get()) }
    single<BookCacheCleanupGateway> { BookCacheCleanupRepository(get()) }
    single<BookExportSettingsGateway> { BookExportSettingsRepository() }
    single<HomepageSettingsGateway> { HomepageSettingsRepository() }
    single<CoverAlbumGateway> { CoverAlbumRepository(get(), get()) }
    single<BookSourceCallbackGateway> { BookSourceCallbackRepository(get(), get()) }
    single<LocalBookGateway> { LocalBookRepository(get()) }
    single<DatabaseMaintenanceGateway> { DatabaseMaintenanceRepository(get()) }
    single<WebDavBackupGateway> { WebDavBackupRepository() }
    single<ReadingProgressGateway> { WebDavReadingProgressRepository() }
    single<HomepageModulesGateway> { HomepageModulesRepository(get(), get()) }
    single<BookDomainRepository> { BookDomainRepositoryImpl(get(), get()) }
    single<BookContentProcessGateway> { BookContentProcessRepository(get()) }
    single<BookMarkingGateway> { BookMarkingRepository(get()) }
    single<BookKnowledgeGateway> { BookKnowledgeRepository(get()) }
    single<ReadAloudVoiceGateway> { ReadAloudVoiceRepository(get()) }
    singleOf(::CloudTtsCredentialCipher)
    single<CloudTtsEngineGateway> { CloudTtsEngineRepository(get(), get()) }
    single<ChapterSpeechGateway> { ChapterSpeechRepository(get()) }
    single { ExploreRepositoryImpl(get()) }
    single<ExploreRepository> { get<ExploreRepositoryImpl>() }
    single<ExploreBooksGateway> { get<ExploreRepositoryImpl>() }
    singleOf(::RssRepository)
    singleOf(::RssFavoriteRepository)
    singleOf(::RssArticleRepository)
    singleOf(::RssReadRecordRepository)
    singleOf(::RssSourceEditRepository)
    singleOf(::RuleSubscriptionRepository)
    single {
        SearchRepositoryImpl(get())
    }
    single<SearchRepository> { get<SearchRepositoryImpl>() }
    single<BookSearchGateway> { get<SearchRepositoryImpl>() }
    singleOf(::SearchBooksUseCase)
    singleOf(::ChangeSourceSearchUseCase)
    singleOf(::GetChapterContentUseCase)
    singleOf(::CheckBookContentQualityUseCase)
    singleOf(::AiToolAwareGenerationUseCase)
    singleOf(::AiTaskManager)
    singleOf(::IdentifyBookCharactersUseCase)
    singleOf(::GenerateChapterSummaryUseCase)
    singleOf(::AiTextFactoryUseCase)
    singleOf(::GenerateBookshelfAutoGroupPlanUseCase)
    singleOf(::ApplyBookshelfAutoGroupPlanUseCase)
    singleOf(::CleanSelectedTextUseCase)
    singleOf(::SaveBookContentProcessUseCase)
    singleOf(::SaveMarkingUseCase)
    singleOf(::VerifyBookmarkTargetUseCase)
    singleOf(::RelocateMarkingTargetUseCase)
    singleOf(::ReplaceRuleRepository)
    single<DictionaryGateway> { DictionaryRepositoryImpl() }
    singleOf(::TranslateChapterUseCase)
    singleOf(::AiChatGenerationUseCase)

    single<ImageLoader> {
        ImageLoader.Builder(get())
            .components {
                if (Build.VERSION.SDK_INT >= 28) {
                    add(AnimatedImageDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
                add(SvgDecoder.Factory())
                add(CoverInterceptor())
                add(CoverFetcher.Factory(okHttpClient, okHttpClientManga))
            }
            .crossfade(true)
            .build()
    }
    // 书架首屏封面预热：依赖上面的 ImageLoader 单例，进程内复用已缓存封面
    singleOf(::BookshelfCoverPreloader)

    viewModelOf(::DictRuleViewModel)
    viewModelOf(::ImportDictRuleViewModel)
    viewModelOf(::ImportHttpTtsViewModel)
    viewModelOf(::ImportReplaceRuleViewModel)
    viewModelOf(::ImportRssSourceViewModel)
    viewModelOf(::ImportTxtTocRuleViewModel)
    viewModelOf(::HighlightTagRuleViewModel)
    viewModelOf(::MultiRoleRuleViewModel)
    viewModelOf(::BgmPoolViewModel)
    viewModelOf(::RegexCastRuleViewModel)
    viewModelOf(::VoiceEffectViewModel)
    viewModelOf(::MultiRoleRecognitionViewModel)
    singleOf(::AiCastAssignUseCase)
    singleOf(::AiSceneAssignUseCase)
    viewModelOf(::TagGroupRuleViewModel)
    viewModelOf(::DictViewModel)
    viewModelOf(::RssSourceViewModel)
    viewModelOf(::BookSourceViewModel)
    viewModelOf(::BookSourceEditViewModel)
    viewModelOf(::BookSourceDebugViewModel)
    viewModelOf(::RssSourceEditViewModel)
    viewModelOf(::RssSourceDebugViewModel)
    viewModelOf(::RssSortViewModel)
    viewModelOf(::RssArticlesViewModel)
    viewModelOf(::ReadRssViewModel)
    viewModelOf(::RssFavoritesViewModel)
    viewModelOf(::RuleSubViewModel)
    viewModelOf(::ReadRecordViewModel)
    viewModelOf(::ReadRecordOverviewViewModel)
    viewModelOf(::ExploreShowViewModel)
    viewModelOf(::MyViewModel)
    viewModelOf(::BookshelfViewModel)
    viewModelOf(::AiAutoGroupViewModel)
    viewModelOf(::MainViewModel)
    viewModelOf(::HomeViewModel)
    viewModelOf(::HomepageViewModel)
    viewModelOf(::AboutViewModel)
    viewModelOf(::GroupViewModel)
    viewModelOf(::ReplaceRuleViewModel)
    viewModelOf(::AllBookmarkViewModel)
    viewModelOf(::TxtTocRuleViewModel)
    viewModel {
        TxtTocRulePreviewViewModel(
            app = get(),
            bookRepository = get(),
            repository = get(),
        )
    }
    viewModel {
        OtherConfigViewModel(
            appLocaleGateway = get(),
            readAloudSettingsGateway = get(),
            otherSettingsGateway = get(),
            downloadCacheSettingsGateway = get(),
            directLinkSettingsGateway = get(),
            systemGateway = get(),
        )
    }
    viewModelOf(::PrivateConfigViewModel)
    // 阅读器入口的私密闸门：阅读记录 / 通知栏 / 深链等直开阅读器的路径都收在这里
    viewModelOf(::PrivateReadGateViewModel)
    viewModelOf(::CustomThemeViewModel)
    viewModelOf(::ReadConfigViewModel)
    viewModelOf(::CoverConfigViewModel)
    viewModelOf(::CoverAlbumManageViewModel)
    viewModelOf(::DownloadCacheConfigViewModel)
    viewModelOf(::ThemeConfigViewModel)
    viewModelOf(::ThemeManageViewModel)
    viewModelOf(::OnboardingViewModel)
    viewModelOf(::BackupConfigViewModel)
    viewModelOf(::LabConfigViewModel)
    viewModelOf(::TranslationConfigViewModel)
    viewModelOf(::AiConfigViewModel)
    viewModelOf(::AiSummaryConfigViewModel)
    viewModelOf(::AiPromptConfigViewModel)
    viewModelOf(::AiChatViewModel)
    viewModel { (providerId: String?) ->
        AiProviderEditViewModel(
            initialProviderId = providerId,
            aiProfileGateway = get(),
            aiTextGateway = get()
        )
    }
    viewModel { (providerId: String?, modelProfileId: String?) ->
        AiModelEditViewModel(
            initialProviderId = providerId,
            initialModelProfileId = modelProfileId,
            aiProfileGateway = get(),
            aiTextGateway = get()
        )
    }
    viewModelOf(::TocViewModel)
    viewModelOf(::ImportBookViewModel)
    viewModelOf(::RemoteBookViewModel)
    viewModelOf(::ServerConfigViewModel)
    viewModelOf(::ServersViewModel)
    viewModelOf(::BookInfoViewModel)
    viewModel {
        WebViewModel(
            application = get(),
            bookSourceRepository = get(),
        )
    }
    viewModel {
        BookInfoEditViewModel(
            application = get(),
            bookRepository = get(),
        )
    }
    viewModel {
        AudioPlayViewModel(
            application = get(),
            coordinator = get(),
            bookRepository = get(),
            otherSettingsGateway = get(),
            readAloudSettingsGateway = get(),
            readSettingsGateway = get(),
        )
    }
    singleOf(::AudioPlayCoordinator)
    viewModel {
        SourceLoginViewModel(
            application = get(),
            bookRepository = get(),
            bookSourceRepository = get(),
            rssRepository = get(),
            httpTtsRepository = get(),
            searchRepository = get(),
            downloadCacheSettingsGateway = get(),
        )
    }
    viewModel { (bookUrl: String, characterId: String?) ->
        BookCharacterDetailViewModel(
            bookUrl = bookUrl,
            characterId = characterId,
            bookKnowledgeGateway = get(),
        )
    }
    viewModel { (bookUrl: String) ->
        BookCharacterNetworkViewModel(
            bookUrl = bookUrl,
            bookKnowledgeGateway = get(),
        )
    }
    viewModel { (bookUrl: String) ->
        BookKnowledgeListViewModel(
            bookUrl = bookUrl,
            bookKnowledgeGateway = get(),
        )
    }
    viewModel { (bookUrl: String) ->
        BookCharacterListViewModel(
            bookUrl = bookUrl,
            bookKnowledgeGateway = get(),
            identifyBookCharacters = get(),
        )
    }
    viewModel { (bookUrl: String) ->
        BookVoiceCastingViewModel(
            bookUrl = bookUrl,
            bookKnowledgeGateway = get(),
            voiceGateway = get(),
            styleGateway = get(),
        )
    }
    viewModelOf(::CloudTtsViewModel)
    viewModelOf(::TtsCacheViewModel)
    singleOf(::ReadAloudPlayerCoordinator)
    /**
     * 朗读播放界面状态宿主。
     *
     * 用单例而不是 `viewModelOf`：悬浮胶囊（Activity 叠层）与听书页目的地会同时存在，
     * 若各自持有实例，`activeSheet` 之类的瞬态状态与设置快照就会各改各的。
     * 播放状态本身在 `ReadAloudSessionStore`/服务里，这里只是界面投影。
     */
    single { ReadAloudPlayerViewModel(get(), get(), get()) }
    viewModel { (bookUrl: String, entryId: String?) ->
        BookKnowledgeDetailViewModel(
            bookUrl = bookUrl,
            entryId = entryId,
            bookKnowledgeGateway = get(),
        )
    }
    viewModel { (bookUrl: String) ->
        BookEventListViewModel(
            bookUrl = bookUrl,
            bookKnowledgeGateway = get(),
        )
    }
    viewModel { (bookUrl: String, eventId: String?) ->
        BookEventDetailViewModel(
            bookUrl = bookUrl,
            eventId = eventId,
            bookKnowledgeGateway = get(),
        )
    }
    viewModelOf(::MangaReaderViewModel)
    viewModelOf(::ReaderSessionViewModel)
    viewModel {
        ReadBookViewModel(
            application = get(),
            getReadingProgressUseCase = get(),
            uploadReadingProgressUseCase = get(),
            translateChapterUseCase = get(),
            readSettingsRepository = get(),
            readBookStyleConfigRepository = get(),
            readAloudSettingsRepository = get(),
            aiCastAssignUseCase = get(),
            aiSceneAssignUseCase = get(),
            localPreferencesRepository = get(),
            highlightRuleRepository = get(),
            uploadRepository = get(),
            changeBookSourceUseCase = get(),
            generateChapterSummaryUseCase = get(),
            cleanSelectedTextUseCase = get(),
            aiTextFactoryUseCase = get(),
            saveBookContentProcessUseCase = get(),
            saveMarkingUseCase = get(),
            verifyBookmarkTargetUseCase = get(),
            relocateMarkingTargetUseCase = get(),
            bookContentProcessGateway = get(),
            aiArtifactGateway = get(),
            aiPromptPresetGateway = get(),
            aiProfileGateway = get(),
            syncReadAloudVoicesUseCase = get(),
            readAloudSessionStore = get(),
            replaceRuleRepository = get(),
            changeSourceSettingsGateway = get(),
            appShellSettingsGateway = get(),
            appUiConfigurationGateway = get(),
            otherSettingsGateway = get(),
            downloadCacheSettingsGateway = get(),
            backupSettingsGateway = get(),
            themeSettingsGateway = get(),
            httpTtsRepository = get(),
            bookSourceRepository = get(),
            bookmarkRepository = get(),
            bookRepository = get(),
            readRecordRepository = get(),
            readerSession = get(),
        )
    }
    viewModelOf(::ChangeCoverViewModel)
    viewModelOf(::ChangeBookSourceComposeViewModel)
    viewModelOf(::ChangeChapterSourceViewModel)
    viewModelOf(::ExploreViewModel)
    viewModelOf(::ExploreMainViewModel)
    viewModelOf(::RssViewModel)
    viewModelOf(::SearchViewModel)
    viewModelOf(::BookCacheManageViewModel)
    viewModel {
        BookshelfManageScreenViewModel(
            application = get(),
            bookRepository = get(),
            bookSourceRepository = get(),
            bookGroupRepository = get(),
            searchRepository = get(),
            bookshelfManageScreenConfig = get(),
            bookExportSettingsGateway = get(),
            batchCacheDownloadUseCase = get(),
            cacheBookChaptersUseCase = get(),
            changeBookSourceUseCase = get(),
            clearBookCacheUseCase = get(),
            deleteBooksUseCase = get(),
            updateBooksGroupUseCase = get(),
            downloadCacheSettingsGateway = get()
        )
    }

    viewModel { (route: ReplaceEditRoute) ->
        ReplaceEditViewModel(
            app = get(),
            replaceRuleRepository = get(),
            route = route
        )
    }

    viewModel { (route: MainRouteSearchContent) ->
        SearchContentViewModel(
            bookUrl = route.bookUrl,
            initialSearchWord = route.searchWord,
            searchResultIndex = route.searchResultIndex,
            bookRepository = get(),
            searchContentRepository = get(),
            themeSettingsGateway = get(),
        )
    }
}
