package io.legado.app.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import io.legado.app.data.entities.readRecord.HomeRecentBookRow
import io.legado.app.data.entities.readRecord.ReadRecord
import io.legado.app.data.entities.readRecord.ReadRecordDetail
import io.legado.app.data.entities.readRecord.ReadRecordSession
import kotlinx.coroutines.flow.Flow

@Dao
interface ReadRecordDao {

    @get:Query("select * from readRecord")
    val all: List<ReadRecord>

    @get:Query("select * from readRecordDetail")
    val allDetail: List<ReadRecordDetail>

    @get:Query("select * from readRecordSession")
    val allSession: List<ReadRecordSession>

    @Query("SELECT sum(readTime) FROM readRecord")
    fun getTotalReadTime(): Flow<Long?>

    @Query(
        """
        SELECT COUNT(*) FROM (
            SELECT 1
            FROM readRecord
            GROUP BY bookName, bookAuthor
        )
        """
    )
    fun observeTotalReadBookCount(): Flow<Int>

    @Query("SELECT SUM(readTime) FROM readRecordDetail WHERE date = :date")
    fun observeReadTimeByDate(date: String): Flow<Long?>

    @Query(
        """
        WITH recent AS (
            SELECT
                bookName,
                bookAuthor,
                MAX(lastRead) AS lastRead
            FROM readRecord
            GROUP BY bookName, bookAuthor
            ORDER BY lastRead DESC
            LIMIT :limit
        )
        SELECT
            recent.bookName AS recordName,
            recent.bookAuthor AS recordAuthor,
            book.bookUrl AS bookUrl,
            book.origin AS origin,
            book.coverUrl AS coverUrl,
            book.customCoverUrl AS customCoverUrl,
            book.durChapterTitle AS chapterTitle,
            book.totalChapterNum AS totalChapterNum,
            book.durChapterIndex AS chapterIndex
        FROM recent
        LEFT JOIN books AS book ON book.bookUrl = (
            SELECT candidate.bookUrl
            FROM books AS candidate
            WHERE candidate.name = recent.bookName
                AND candidate.author = recent.bookAuthor
            ORDER BY candidate.durChapterTime DESC, candidate.bookUrl ASC
            LIMIT 1
        )
        ORDER BY recent.lastRead DESC
        """
    )
    fun observeRecentHomeBooks(limit: Int): Flow<List<HomeRecentBookRow>>

    @Query("select sum(readTime) from readRecord where bookName = :bookName")
    fun getReadTime(bookName: String): Long?

    @Query("select readTime from readRecord where deviceId = :deviceId and bookName = :bookName and bookAuthor = :bookAuthor")
    fun getReadTime(deviceId: String, bookName: String, bookAuthor: String): Long?

    @Query("SELECT * FROM readRecord WHERE deviceId = :deviceId AND bookName = :bookName AND bookAuthor = :bookAuthor")
    suspend fun getReadRecord(deviceId: String, bookName: String, bookAuthor: String): ReadRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(vararg readRecord: ReadRecord)

    @Update
    suspend fun update(vararg record: ReadRecord)

    @Delete
    fun delete(vararg record: ReadRecord)

    @Query("delete from readRecord")
    fun clear()

    @Query("delete from readRecord where bookName = :bookName and bookAuthor = :bookAuthor")
    fun deleteByName(bookName: String, bookAuthor: String)

    /**
     * 插入或更新每日聚合统计记录。
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDetail(detail: ReadRecordDetail)

    /**
     * 获取某一本书某一天的详细统计
     * @param date 日期, 推荐格式: YYYY-MM-DD
     */
    @Query("SELECT * FROM readRecordDetail WHERE deviceId = :deviceId AND bookName = :bookName AND bookAuthor = :bookAuthor AND date = :date")
    suspend fun getDetail(deviceId: String, bookName: String, bookAuthor: String, date: String): ReadRecordDetail?

    /**
     * 查询所有发生过阅读的日期（用于日历标记）
     */
    @Query("SELECT DISTINCT date FROM readRecordDetail WHERE deviceId = :deviceId ORDER BY date DESC")
    fun getAllReadDates(deviceId: String): List<String>

    /**
     * 获取某一天所有书籍的详细统计 (用于日历页面总览)
     */
    @Query("SELECT * FROM readRecordDetail WHERE deviceId = :deviceId AND date = :date")
    suspend fun getDetailsByDate(deviceId: String, date: String): List<ReadRecordDetail>

    // 清除每天的统计记录
    @Query("DELETE FROM readRecordDetail WHERE bookName = :bookName AND bookAuthor = :bookAuthor")
    fun deleteDetailByName(bookName: String, bookAuthor: String)

    /** 删除指定书籍指定日期的统计详情。 */
    @Query("DELETE FROM readRecordDetail WHERE bookName = :bookName AND bookAuthor = :bookAuthor AND date = :date")
    suspend fun deleteDetailByNameAndDate(bookName: String, bookAuthor: String, date: String)

    /**
     * 获取指定书籍的最后一条阅读时段记录
     * 用于判断是否可以合并
     */
    @Query("SELECT * FROM readRecordSession WHERE bookName = :bookName AND bookAuthor = :bookAuthor ORDER BY endTime DESC LIMIT 1")
    suspend fun getLatestSessionByBook(bookName: String, bookAuthor: String): ReadRecordSession?

    /**
     * 更新现有的阅读时段记录
     */
    @Update
    suspend fun updateSession(session: ReadRecordSession)

    /**
     * 插入阅读时段记录。
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertSession(session: ReadRecordSession)

    /** 获取所有 ReadRecord，按最后阅读时间倒序排列 */
    @Query("SELECT * FROM readRecord ORDER BY lastRead DESC")
    fun getAllReadRecordsSortedByLastRead(): Flow<List<ReadRecord>>

    /** 搜索 ReadRecord，按最后阅读时间倒序排列 */
    @Query("SELECT * FROM readRecord WHERE bookName LIKE '%' || :query || '%' OR bookAuthor LIKE '%' || :query || '%' ORDER BY lastRead DESC")
    fun searchReadRecordsByLastRead(query: String): Flow<List<ReadRecord>>

    @Query("SELECT * FROM readRecord WHERE deviceId = :deviceId AND bookName = :bookName AND bookAuthor != :excludeAuthor ORDER BY lastRead DESC")
    suspend fun getReadRecordsByNameExcludingAuthor(
        deviceId: String,
        bookName: String,
        excludeAuthor: String
    ): List<ReadRecord>

    @Query(
        """
        SELECT * FROM readRecord
        WHERE deviceId = :deviceId
        AND NOT (bookName = :bookName AND bookAuthor = :bookAuthor)
        ORDER BY
            CASE WHEN bookName = :bookName THEN 0 ELSE 1 END,
            lastRead DESC
        """
    )
    suspend fun getMergeCandidates(
        deviceId: String,
        bookName: String,
        bookAuthor: String
    ): List<ReadRecord>

    /** 聚合列表项没有真实设备 ID，跨设备查询可供合并的其他记录。 */
    @Query(
        """
        SELECT * FROM readRecord
        WHERE NOT (bookName = :bookName AND bookAuthor = :bookAuthor)
        ORDER BY CASE WHEN bookName = :bookName THEN 0 ELSE 1 END, lastRead DESC
        """
    )
    suspend fun getMergeCandidatesAcrossDevices(
        bookName: String,
        bookAuthor: String,
    ): List<ReadRecord>

    /**
     * 获取某一天某一本书的所有阅读时段记录
     */
    @Query("""
        SELECT * FROM readRecordSession 
        WHERE deviceId = :deviceId 
        AND bookName = :bookName 
        AND bookAuthor = :bookAuthor 
        AND STRFTIME('%Y-%m-%d', datetime(startTime/1000, 'unixepoch', 'localtime')) = :date 
        ORDER BY startTime ASC
    """)
    suspend fun getSessionsByBookAndDate(
        deviceId: String,
        bookName: String,
        bookAuthor: String,
        date: String
    ): List<ReadRecordSession>

    /**
     * 获取某一天所有书籍的阅读时段记录
     */
    @Query("""
    SELECT * FROM readRecordSession 
    WHERE deviceId = :deviceId 
    AND STRFTIME('%Y-%m-%d', datetime(startTime/1000, 'unixepoch', 'localtime')) = :date 
    ORDER BY startTime ASC
    """)
    suspend fun getSessionsByDate(deviceId: String, date: String): List<ReadRecordSession>

    @Query("SELECT * FROM readRecordDetail WHERE deviceId = :deviceId AND date = :date AND (bookName LIKE '%' || :query || '%' OR bookAuthor LIKE '%' || :query || '%')")
    suspend fun searchDetailsByDate(deviceId: String, date: String, query: String): List<ReadRecordDetail>

    // 清除阅读时段记录
    @Query("DELETE FROM readRecordSession WHERE bookName = :bookName AND bookAuthor = :bookAuthor")
    fun deleteSessionByName(bookName: String, bookAuthor: String)

    /** 按阅读时段内容删除记录，用于跨设备删除同一阅读时段的同步副本。 */
    @Query("DELETE FROM readRecordSession WHERE bookName = :bookName AND bookAuthor = :bookAuthor AND startTime = :startTime AND endTime = :endTime AND words = :words")
    suspend fun deleteSessionByIdentity(
        bookName: String,
        bookAuthor: String,
        startTime: Long,
        endTime: Long,
        words: Long,
    )

    /** 获取所有设备中指定书名和作者的汇总记录。 */
    @Query("SELECT * FROM readRecord WHERE bookName = :bookName AND bookAuthor = :bookAuthor")
    suspend fun getReadRecordsByName(bookName: String, bookAuthor: String): List<ReadRecord>

    /** 获取所有设备中指定书名但作者为空的旧记录。 */
    @Query("SELECT * FROM readRecord WHERE bookName = :bookName AND bookAuthor = ''")
    suspend fun getUnknownAuthorRecords(bookName: String): List<ReadRecord>

    @Query("SELECT * FROM readRecordDetail ORDER BY date DESC, lastReadTime DESC")
    fun getAllDetails(): Flow<List<ReadRecordDetail>>

    @Query("SELECT * FROM readRecordDetail WHERE bookName LIKE '%' || :query || '%' OR bookAuthor LIKE '%' || :query || '%' ORDER BY date DESC, lastReadTime DESC")
    fun searchDetails(query: String): Flow<List<ReadRecordDetail>>

    @Query("SELECT * FROM readRecordSession WHERE deviceId = :deviceId ORDER BY startTime ASC")
    fun getAllSessions(deviceId: String): Flow<List<ReadRecordSession>>

    /** 获取所有设备的阅读时段记录，供跨设备时间线聚合使用。 */
    @Query("SELECT * FROM readRecordSession ORDER BY startTime ASC")
    fun getAllSessions(): Flow<List<ReadRecordSession>>

    @Query("SELECT * FROM readRecordSession WHERE deviceId = :deviceId AND bookName = :bookName AND bookAuthor = :bookAuthor")
    suspend fun getSessionsByBook(deviceId: String, bookName: String, bookAuthor: String): List<ReadRecordSession>

    /** 清理跨设备同步产生的重复阅读时段（忽略 deviceId），只保留最早写入的一行。 */
    @Query(
        """
        DELETE FROM readRecordSession
        WHERE id NOT IN (
            SELECT MIN(id) FROM readRecordSession
            GROUP BY bookName, bookAuthor, bookUrl, startTime, endTime, words
        )
        """
    )
    suspend fun deleteDuplicateSessions()

    /** 阅读记录合并后，仅清理目标设备下该书的重复时段。 */
    @Query(
        """
        DELETE FROM readRecordSession
        WHERE id NOT IN (
            SELECT MIN(id) FROM readRecordSession
            WHERE deviceId = :deviceId AND bookName = :bookName AND bookAuthor = :bookAuthor
            GROUP BY bookName, bookAuthor, bookUrl, startTime, endTime, words
        )
        AND deviceId = :deviceId AND bookName = :bookName AND bookAuthor = :bookAuthor
        """
    )
    suspend fun deleteDuplicateSessionsByBook(deviceId: String, bookName: String, bookAuthor: String)

    @Query(
        """
        SELECT * FROM readRecordSession
        WHERE deviceId = :deviceId
        AND bookName = :bookName
        AND bookAuthor = :bookAuthor
        AND bookUrl = :bookUrl
        AND startTime = :startTime
        AND endTime = :endTime
        AND words = :words
        LIMIT 1
        """
    )
    suspend fun getSession(
        deviceId: String,
        bookName: String,
        bookAuthor: String,
        bookUrl: String,
        startTime: Long,
        endTime: Long,
        words: Long
    ): ReadRecordSession?

    /** 按书籍副本取全部阅读时段，用于副本归属迁移前的快照。 */
    @Query("SELECT * FROM readRecordSession WHERE bookUrl = :bookUrl ORDER BY startTime ASC")
    suspend fun getSessionsByBookUrl(bookUrl: String): List<ReadRecordSession>

    /**
     * 把某个书籍副本的阅读时段整体交给另一个副本。
     *
     * 迁移/换源后旧书被删除，会话必须改挂新副本，否则新副本会从零开始计时、
     * 旧时长变成孤儿；若新书书名作者发生变化，会话的聚合键同步改写。
     */
    @Query(
        """
        UPDATE readRecordSession
        SET bookUrl = :newBookUrl, bookName = :newBookName, bookAuthor = :newBookAuthor
        WHERE bookUrl = :oldBookUrl
        """
    )
    suspend fun reassignSessionOwnership(
        oldBookUrl: String,
        newBookUrl: String,
        newBookName: String,
        newBookAuthor: String,
    )

    @Query("SELECT * FROM readRecordSession WHERE deviceId = :deviceId AND bookName = :bookName AND bookAuthor = :bookAuthor ORDER BY startTime DESC")
    fun getSessionsByBookFlow(deviceId: String, bookName: String, bookAuthor: String): Flow<List<ReadRecordSession>>

    @Query("SELECT SUM(readTime) FROM readRecord WHERE bookName = :bookName AND bookAuthor = :bookAuthor")
    fun getReadTimeFlow(bookName: String, bookAuthor: String): Flow<Long?>

    @Delete
    suspend fun deleteDetail(detail: ReadRecordDetail)

    @Query(
        """
        DELETE FROM readRecordSession 
        WHERE deviceId = :deviceId 
        AND bookName = :bookName 
        AND bookAuthor = :bookAuthor 
        AND STRFTIME('%Y-%m-%d', datetime(startTime/1000, 'unixepoch', 'localtime')) = :date
    """
    )
    suspend fun deleteSessionsByBookAndDate(
        deviceId: String,
        bookName: String,
        bookAuthor: String,
        date: String
    )

    @Delete
    suspend fun deleteSession(session: ReadRecordSession)

    @Delete
    suspend fun deleteReadRecord(record: ReadRecord)

    @Query("DELETE FROM readRecord")
    suspend fun clearReadRecords()

    @Query("DELETE FROM readRecordDetail")
    suspend fun clearReadRecordDetails()

    @Query("DELETE FROM readRecordSession")
    suspend fun clearReadRecordSessions()

    @Query("DELETE FROM readRecordDetail WHERE deviceId = :deviceId AND bookName = :bookName AND bookAuthor = :bookAuthor")
    suspend fun deleteDetailsByBook(deviceId: String, bookName: String, bookAuthor: String)

    @Query("DELETE FROM readRecordSession WHERE deviceId = :deviceId AND bookName = :bookName AND bookAuthor = :bookAuthor")
    suspend fun deleteSessionsByBook(deviceId: String, bookName: String, bookAuthor: String)

    @Query("SELECT * FROM readRecordDetail WHERE deviceId = :deviceId AND bookName = :bookName AND bookAuthor = :bookAuthor")
    suspend fun getDetailsByBook(deviceId: String, bookName: String, bookAuthor: String): List<ReadRecordDetail>

}
